"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Monitor,
  Users,
  Calendar,
  BarChart3,
  Search,
  Plus,
  Bell,
  User,
  Wrench,
  Clock,
  CheckCircle,
  Package,
  BookOpen,
  Mail,
  MapPin,
  Star,
  ArrowRight,
  Shield,
  Zap,
  HeadphonesIcon,
} from "lucide-react"
import { Input } from "@/components/ui/input"

export default function DernSupportDashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")

  const stats = [
    { title: "Active Tickets", value: "24", change: "+12%", icon: Monitor, color: "text-blue-600" },
    { title: "Completed Today", value: "8", change: "+5%", icon: CheckCircle, color: "text-green-600" },
    { title: "Pending Parts", value: "3", change: "-2%", icon: Package, color: "text-orange-600" },
    { title: "Customer Satisfaction", value: "4.8", change: "+0.2", icon: Star, color: "text-yellow-600" },
  ]

  const recentTickets = [
    {
      id: "T001",
      customer: "TechCorp Ltd",
      issue: "Network connectivity",
      priority: "High",
      status: "In Progress",
      time: "2 hours ago",
    },
    {
      id: "T002",
      customer: "John Smith",
      issue: "Laptop won't boot",
      priority: "Medium",
      status: "Pending",
      time: "4 hours ago",
    },
    {
      id: "T003",
      customer: "DataFlow Inc",
      issue: "Server maintenance",
      priority: "Low",
      status: "Scheduled",
      time: "1 day ago",
    },
  ]

  const upcomingJobs = [
    { time: "09:00", customer: "TechCorp Ltd", location: "Downtown Office", type: "On-site" },
    { time: "11:30", customer: "Sarah Johnson", location: "Workshop", type: "Drop-off" },
    { time: "14:00", customer: "MegaData Systems", location: "Industrial Park", type: "On-site" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-blue-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                  <Wrench className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Dern-Support</h1>
                  <p className="text-sm text-gray-600">IT Support Management</p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  placeholder="Search tickets, customers..."
                  className="pl-10 w-64 bg-white/50 border-blue-200 focus:border-blue-400"
                />
              </div>
              <Button variant="outline" size="icon" className="relative border-blue-200 hover:bg-blue-50">
                <Bell className="w-4 h-4" />
                <Badge className="absolute -top-2 -right-2 w-5 h-5 p-0 bg-red-500 text-white text-xs">3</Badge>
              </Button>
              <Button variant="outline" size="icon" className="border-blue-200 hover:bg-blue-50">
                <User className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Navigation */}
          <TabsList className="grid w-full grid-cols-6 bg-white/50 backdrop-blur-sm border border-blue-200">
            <TabsTrigger value="dashboard" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger value="tickets" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Monitor className="w-4 h-4 mr-2" />
              Tickets
            </TabsTrigger>
            <TabsTrigger value="customers" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Users className="w-4 h-4 mr-2" />
              Customers
            </TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </TabsTrigger>
            <TabsTrigger value="inventory" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <Package className="w-4 h-4 mr-2" />
              Inventory
            </TabsTrigger>
            <TabsTrigger value="knowledge" className="data-[state=active]:bg-blue-600 data-[state=active]:text-white">
              <BookOpen className="w-4 h-4 mr-2" />
              Knowledge Base
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => (
                <Card
                  key={index}
                  className="bg-white/60 backdrop-blur-sm border-blue-200 hover:shadow-lg transition-all duration-300"
                >
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                        <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                        <p className="text-sm text-green-600">{stat.change} from last week</p>
                      </div>
                      <stat.icon className={`w-8 h-8 ${stat.color}`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Tickets */}
              <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Recent Tickets
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      New Ticket
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentTickets.map((ticket) => (
                      <div
                        key={ticket.id}
                        className="flex items-center justify-between p-3 bg-white/50 rounded-lg border border-blue-100"
                      >
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline" className="text-xs">
                              {ticket.id}
                            </Badge>
                            <Badge
                              variant={
                                ticket.priority === "High"
                                  ? "destructive"
                                  : ticket.priority === "Medium"
                                    ? "default"
                                    : "secondary"
                              }
                              className="text-xs"
                            >
                              {ticket.priority}
                            </Badge>
                          </div>
                          <p className="font-medium text-gray-900 mt-1">{ticket.customer}</p>
                          <p className="text-sm text-gray-600">{ticket.issue}</p>
                          <p className="text-xs text-gray-500">{ticket.time}</p>
                        </div>
                        <Badge variant={ticket.status === "In Progress" ? "default" : "secondary"} className="ml-4">
                          {ticket.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Today's Schedule */}
              <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Today's Schedule
                    <Button size="sm" variant="outline" className="border-blue-200 hover:bg-blue-50">
                      <Calendar className="w-4 h-4 mr-2" />
                      View All
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {upcomingJobs.map((job, index) => (
                      <div
                        key={index}
                        className="flex items-center space-x-4 p-3 bg-white/50 rounded-lg border border-blue-100"
                      >
                        <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg">
                          <Clock className="w-6 h-6 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <p className="font-medium text-gray-900">{job.time}</p>
                            <Badge variant="outline" className="text-xs">
                              {job.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">{job.customer}</p>
                          <p className="text-xs text-gray-500 flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {job.location}
                          </p>
                        </div>
                        <Button size="sm" variant="ghost" className="hover:bg-blue-50">
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tickets Tab */}
          <TabsContent value="tickets" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle>Support Tickets</CardTitle>
                <CardDescription>Manage and track all customer support requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <Input placeholder="Search tickets..." className="w-64 bg-white/50 border-blue-200" />
                    <Button variant="outline" className="border-blue-200 hover:bg-blue-50">
                      Filter
                    </Button>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Ticket
                  </Button>
                </div>

                <div className="space-y-4">
                  {recentTickets.map((ticket) => (
                    <div
                      key={ticket.id}
                      className="p-4 bg-white/50 rounded-lg border border-blue-100 hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-lg">
                            <Monitor className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h3 className="font-medium text-gray-900">{ticket.id}</h3>
                              <Badge
                                variant={
                                  ticket.priority === "High"
                                    ? "destructive"
                                    : ticket.priority === "Medium"
                                      ? "default"
                                      : "secondary"
                                }
                              >
                                {ticket.priority}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-600">
                              {ticket.customer} • {ticket.issue}
                            </p>
                            <p className="text-xs text-gray-500">{ticket.time}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{ticket.status}</Badge>
                          <Button size="sm" variant="ghost" className="hover:bg-blue-50">
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Customers Tab */}
          <TabsContent value="customers" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle>Customer Management</CardTitle>
                <CardDescription>Manage business and individual customer accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <Input placeholder="Search customers..." className="w-64 bg-white/50 border-blue-200" />
                    <Button variant="outline" className="border-blue-200 hover:bg-blue-50">
                      Filter
                    </Button>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Customer
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    {
                      name: "TechCorp Ltd",
                      type: "Business",
                      tickets: 12,
                      status: "Active",
                      contact: "john@techcorp.com",
                    },
                    {
                      name: "Sarah Johnson",
                      type: "Individual",
                      tickets: 3,
                      status: "Active",
                      contact: "sarah.j@email.com",
                    },
                    {
                      name: "DataFlow Inc",
                      type: "Business",
                      tickets: 8,
                      status: "Active",
                      contact: "support@dataflow.com",
                    },
                  ].map((customer, index) => (
                    <Card key={index} className="bg-white/50 border-blue-100 hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <User className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <h3 className="font-medium text-gray-900">{customer.name}</h3>
                              <Badge variant="outline" className="text-xs">
                                {customer.type}
                              </Badge>
                            </div>
                          </div>
                          <Badge variant="secondary">{customer.status}</Badge>
                        </div>
                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Mail className="w-4 h-4 mr-2" />
                            {customer.contact}
                          </div>
                          <div className="flex items-center">
                            <Monitor className="w-4 h-4 mr-2" />
                            {customer.tickets} tickets
                          </div>
                        </div>
                        <Button size="sm" variant="ghost" className="w-full mt-3 hover:bg-blue-50">
                          View Profile
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle>Work Schedule</CardTitle>
                <CardDescription>Plan and prioritize daily tasks and appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <div className="bg-white/50 rounded-lg border border-blue-100 p-4">
                      <h3 className="font-medium text-gray-900 mb-4">Today's Schedule</h3>
                      <div className="space-y-3">
                        {upcomingJobs.map((job, index) => (
                          <div
                            key={index}
                            className="flex items-center space-x-4 p-3 bg-white/50 rounded-lg border border-blue-100"
                          >
                            <div className="text-sm font-medium text-blue-600 w-16">{job.time}</div>
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">{job.customer}</p>
                              <p className="text-sm text-gray-600 flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {job.location}
                              </p>
                            </div>
                            <Badge variant="outline">{job.type}</Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-white/50 border-blue-100">
                      <CardContent className="p-4">
                        <h3 className="font-medium text-gray-900 mb-3">Quick Actions</h3>
                        <div className="space-y-2">
                          <Button className="w-full justify-start bg-blue-600 hover:bg-blue-700">
                            <Plus className="w-4 h-4 mr-2" />
                            Schedule Appointment
                          </Button>
                          <Button variant="outline" className="w-full justify-start border-blue-200 hover:bg-blue-50">
                            <Calendar className="w-4 h-4 mr-2" />
                            View Calendar
                          </Button>
                          <Button variant="outline" className="w-full justify-start border-blue-200 hover:bg-blue-50">
                            <Clock className="w-4 h-4 mr-2" />
                            Time Tracking
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Inventory Tab */}
          <TabsContent value="inventory" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle>Parts Inventory</CardTitle>
                <CardDescription>Search and manage spare parts inventory</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <Input placeholder="Search parts..." className="w-64 bg-white/50 border-blue-200" />
                    <Button variant="outline" className="border-blue-200 hover:bg-blue-50">
                      Filter
                    </Button>
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Part
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {[
                    { name: "RAM 8GB DDR4", sku: "RAM-8GB-001", stock: 15, price: "$89.99", status: "In Stock" },
                    { name: "SSD 500GB", sku: "SSD-500-002", stock: 8, price: "$129.99", status: "In Stock" },
                    { name: "Power Supply 650W", sku: "PSU-650-003", stock: 2, price: "$79.99", status: "Low Stock" },
                    {
                      name: "Graphics Card GTX",
                      sku: "GPU-GTX-004",
                      stock: 0,
                      price: "$299.99",
                      status: "Out of Stock",
                    },
                  ].map((part, index) => (
                    <Card key={index} className="bg-white/50 border-blue-100 hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Package className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <h3 className="font-medium text-gray-900">{part.name}</h3>
                              <p className="text-xs text-gray-500">{part.sku}</p>
                            </div>
                          </div>
                          <Badge
                            variant={
                              part.status === "In Stock"
                                ? "secondary"
                                : part.status === "Low Stock"
                                  ? "default"
                                  : "destructive"
                            }
                          >
                            {part.status}
                          </Badge>
                        </div>
                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex justify-between">
                            <span>Stock:</span>
                            <span className="font-medium">{part.stock} units</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Price:</span>
                            <span className="font-medium text-green-600">{part.price}</span>
                          </div>
                        </div>
                        <Button size="sm" variant="ghost" className="w-full mt-3 hover:bg-blue-50">
                          Edit Details
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Knowledge Base Tab */}
          <TabsContent value="knowledge" className="space-y-6">
            <Card className="bg-white/60 backdrop-blur-sm border-blue-200">
              <CardHeader>
                <CardTitle>Knowledge Base</CardTitle>
                <CardDescription>Problem diagnosis and troubleshooting guides</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <div className="mb-6">
                      <Input placeholder="Search knowledge base..." className="w-full bg-white/50 border-blue-200" />
                    </div>

                    <div className="space-y-4">
                      {[
                        {
                          title: "Computer Won't Start",
                          category: "Hardware",
                          views: 1250,
                          difficulty: "Beginner",
                          description: "Step-by-step guide to diagnose startup issues",
                        },
                        {
                          title: "Network Connection Problems",
                          category: "Network",
                          views: 890,
                          difficulty: "Intermediate",
                          description: "Troubleshoot common network connectivity issues",
                        },
                        {
                          title: "Software Installation Errors",
                          category: "Software",
                          views: 675,
                          difficulty: "Beginner",
                          description: "Resolve common software installation problems",
                        },
                        {
                          title: "Blue Screen of Death (BSOD)",
                          category: "Hardware",
                          views: 1100,
                          difficulty: "Advanced",
                          description: "Diagnose and fix Windows blue screen errors",
                        },
                      ].map((article, index) => (
                        <Card
                          key={index}
                          className="bg-white/50 border-blue-100 hover:shadow-md transition-shadow cursor-pointer"
                        >
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center space-x-2 mb-2">
                                  <h3 className="font-medium text-gray-900">{article.title}</h3>
                                  <Badge variant="outline" className="text-xs">
                                    {article.category}
                                  </Badge>
                                  <Badge
                                    variant={
                                      article.difficulty === "Beginner"
                                        ? "secondary"
                                        : article.difficulty === "Intermediate"
                                          ? "default"
                                          : "destructive"
                                    }
                                    className="text-xs"
                                  >
                                    {article.difficulty}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-600 mb-2">{article.description}</p>
                                <p className="text-xs text-gray-500">{article.views} views</p>
                              </div>
                              <Button size="sm" variant="ghost" className="hover:bg-blue-50">
                                <ArrowRight className="w-4 h-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <Card className="bg-white/50 border-blue-100">
                      <CardContent className="p-4">
                        <h3 className="font-medium text-gray-900 mb-3">Categories</h3>
                        <div className="space-y-2">
                          {[
                            { name: "Hardware", count: 45 },
                            { name: "Software", count: 32 },
                            { name: "Network", count: 28 },
                            { name: "Security", count: 15 },
                          ].map((category, index) => (
                            <div
                              key={index}
                              className="flex items-center justify-between p-2 hover:bg-blue-50 rounded cursor-pointer"
                            >
                              <span className="text-sm text-gray-700">{category.name}</span>
                              <Badge variant="secondary" className="text-xs">
                                {category.count}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-white/50 border-blue-100">
                      <CardContent className="p-4">
                        <h3 className="font-medium text-gray-900 mb-3">Quick Tools</h3>
                        <div className="space-y-2">
                          <Button variant="outline" className="w-full justify-start border-blue-200 hover:bg-blue-50">
                            <Shield className="w-4 h-4 mr-2" />
                            System Diagnostics
                          </Button>
                          <Button variant="outline" className="w-full justify-start border-blue-200 hover:bg-blue-50">
                            <Zap className="w-4 h-4 mr-2" />
                            Performance Test
                          </Button>
                          <Button variant="outline" className="w-full justify-start border-blue-200 hover:bg-blue-50">
                            <HeadphonesIcon className="w-4 h-4 mr-2" />
                            Remote Support
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
